package com.htmltoapk.mr_prompt_ai;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.htmltoapk.mr_prompt_ai.util.IabHelper;
import com.htmltoapk.mr_prompt_ai.util.IabResult;
import com.htmltoapk.mr_prompt_ai.util.Inventory;
import com.htmltoapk.mr_prompt_ai.util.Purchase;

import org.json.JSONObject;

import java.util.UUID;

/**
 * WebView that runs assets/index.html and connects its "buy" button to Myket in-app billing.
 *
 * JS -> native (window.Android): buyPremium(), checkPremium(), copyText(t), shareText(t), openUrl(u)
 * native -> JS: window.onPremiumState(bool), window.onPremiumResult(bool, message)
 */
public class MainActivity extends Activity {

    /** Product id created in the Myket developer panel. */
    private static final String SKU_PREMIUM = "N0931";
    private static final int RC_REQUEST = 10001;
    private static final String PREFS = "pm_prefs";
    private static final int ITEM_ALREADY_OWNED = 7;

    private WebView webView;
    private IabHelper mHelper;
    private boolean mReady = false;
    private boolean mPendingCheck = false;
    private boolean mBuying = false;
    private boolean mAnnounce = false;

    /** The RSA public key is rebuilt at run time (Myket recommends not keeping it as one literal). */
    private static String publicKey() {
        String[] p = {
            "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDLVvrKqNGVCkxnoQS",
            "gS6MRqQB4QGb4kuQcO4DIHqHC7ChWyB1P1D0qSK8gDtc9rUyjuj27jg",
            "jChnXuKvOn8t9Xz+qEzAz4m5HfQ/RApGayUSmwOsmrg0U5hzgP7EU78",
            "rMWzWVofq+3D/M8C5hwrUbijW/qRGSc+3++XGwj/jNf+wIDAQAB"
        };
        StringBuilder sb = new StringBuilder();
        for (String s : p) sb.append(s);
        return sb.toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#1a0f3d"));
        w.setNavigationBarColor(Color.parseColor("#1a0f3d"));

        webView = new WebView(this);
        setContentView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);          // needed for localStorage (progress, scores, ...)
        ws.setAllowFileAccess(true);
        ws.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                if (u.startsWith("file:")) return false;
                openExternal(u);
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");

        setupBilling();
    }

    // ------------------------------------------------------------------ billing

    private void setupBilling() {
        try {
            mHelper = new IabHelper(this, publicKey());
            mHelper.startSetup(new IabHelper.OnIabSetupFinishedListener() {
                @Override
                public void onIabSetupFinished(IabResult result) {
                    mReady = result != null && result.isSuccess();
                    if (mReady) {
                        // Always refresh ownership after connecting so a previous
                        // non-consumable purchase survives app restarts/reinstalls.
                        doCheck();
                    } else {
                        mPendingCheck = false;
                        String msg = result == null ?
                                "اتصال به مایکت برقرار نشد" : result.getMessage();
                        js("onPremiumState(false)");
                    }
                }
            });
        } catch (Exception e) {
            mReady = false;
        }
    }

    private void startPurchase() {
        if (!mReady || mHelper == null) {
            js("onPremiumResult(false," + q("اتصال به مایکت برقرار نیست؛ مایکت را نصب و به‌روز کنید") + ")");
            return;
        }
        if (mBuying) return;
        mBuying = true;
        String payload = UUID.randomUUID().toString();
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("payload", payload).apply();
        try {
            mHelper.launchPurchaseFlow(this, SKU_PREMIUM, RC_REQUEST, mPurchaseFinished, payload);
        } catch (Exception e) {
            mBuying = false;
            js("onPremiumResult(false," + q("شروع خرید ممکن نشد") + ")");
        }
    }

    private void doCheck() {
        if (mHelper == null || !mReady) return;
        try {
            mHelper.queryInventoryAsync(mGotInventory);
        } catch (Exception e) {
            // another billing operation is running; ignore
        }
    }

    private final IabHelper.OnIabPurchaseFinishedListener mPurchaseFinished =
            new IabHelper.OnIabPurchaseFinishedListener() {
        @Override
        public void onIabPurchaseFinished(IabResult result, Purchase purchase) {
            mBuying = false;
            if (mHelper == null) return;
            if (result.isFailure()) {
                if (result.getResponse() == ITEM_ALREADY_OWNED) {
                    mAnnounce = true;      // already bought before: restore it
                    doCheck();
                } else {
                    js("onPremiumResult(false," + q("خرید انجام نشد") + ")");
                }
                return;
            }
            String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString("payload", "");
            String purchasePackage = purchase == null ? "" : purchase.getPackageName();
            if (purchase == null
                    || !SKU_PREMIUM.equals(purchase.getSku())
                    || !getPackageName().equals(purchasePackage)
                    || purchase.getPurchaseState() != 0
                    || !saved.equals(purchase.getDeveloperPayload())) {
                js("onPremiumResult(false," + q("تأیید خرید ناموفق بود") + ")");
                return;
            }
            js("onPremiumResult(true,\"\")");
        }
    };

    private final IabHelper.QueryInventoryFinishedListener mGotInventory =
            new IabHelper.QueryInventoryFinishedListener() {
        @Override
        public void onQueryInventoryFinished(IabResult result, Inventory inventory) {
            if (mHelper == null || result == null || result.isFailure() || inventory == null) {
                mAnnounce = false;
                return;   // unknown state: never revoke the subscription because of a failed query
            }
            Purchase p = inventory.getPurchase(SKU_PREMIUM);
            boolean ok = (p != null && p.getPurchaseState() == 0);
            if (ok && mAnnounce) {
                js("onPremiumResult(true,\"\")");
            } else {
                js("onPremiumState(" + ok + ")");
            }
            mAnnounce = false;
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (mHelper == null || !mHelper.handleActivityResult(requestCode, resultCode, data)) {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    // ------------------------------------------------------------------ bridge

    public class Bridge {
        @JavascriptInterface
        public void buyPremium() {
            runOnUiThread(new Runnable() { public void run() { startPurchase(); } });
        }

        @JavascriptInterface
        public void checkPremium() {
            runOnUiThread(new Runnable() {
                public void run() {
                    if (mReady) doCheck(); else mPendingCheck = true;
                }
            });
        }

        @JavascriptInterface
        public void copyText(final String t) {
            runOnUiThread(new Runnable() {
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("text", t));
                }
            });
        }

        @JavascriptInterface
        public void shareText(final String t) {
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, t);
                    startActivity(Intent.createChooser(i, null));
                }
            });
        }

        @JavascriptInterface
        public void openUrl(final String u) {
            runOnUiThread(new Runnable() { public void run() { openExternal(u); } });
        }
    }

    // ------------------------------------------------------------------ helpers

    private void js(final String call) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (webView != null) webView.evaluateJavascript("window." + call, null);
            }
        });
    }

    private static String q(String s) {
        return JSONObject.quote(s);
    }

    private void openExternal(String u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
        } catch (Exception ignored) { }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Re-check a non-consumable purchase whenever the app returns to the foreground.
        if (mReady && !mBuying) doCheck();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mHelper != null) mHelper.dispose();
        mHelper = null;
        if (webView != null) { webView.destroy(); webView = null; }
    }
}
